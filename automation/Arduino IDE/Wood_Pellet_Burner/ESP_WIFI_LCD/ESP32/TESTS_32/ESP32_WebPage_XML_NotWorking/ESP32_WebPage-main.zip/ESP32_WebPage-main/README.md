
<b><h2><center>Sampe code for updating a web page and getting user actions sent back the the microcontroller</center></h1></b>

This sample code will show you how to create an access point, serve a web page, updated just changed data, and get user interactions such as button presses and slider actions sent back to the microcontrller.

You will need an ESP32 and some open source libraries.

<br>
<br>

![header image](https://raw.github.com/KrisKasprzak/ESP32_WebPage/master/screen.jpg)
